﻿namespace EMPLEADOSGUARDAR
{
    internal class CARGO
    {
    }
}