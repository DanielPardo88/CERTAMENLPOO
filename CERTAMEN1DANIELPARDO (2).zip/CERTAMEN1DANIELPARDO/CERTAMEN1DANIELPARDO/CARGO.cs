﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CERTAMEN1DANIELPARDO
{
    class CARGO: Entity
    {
        
        public string nombrecargo { get; set; }

        public CARGO(int id, string nombrecargo)
        {
            this.id = id;
            this.nombrecargo = nombrecargo;
        }

        public CARGO()
        {
        }
    }
}
