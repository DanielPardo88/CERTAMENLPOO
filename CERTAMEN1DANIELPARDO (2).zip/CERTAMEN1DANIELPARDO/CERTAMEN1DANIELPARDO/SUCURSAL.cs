﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CERTAMEN1DANIELPARDO
{
    class SUCURSAL: Entity
    {

        
        public string ciudad { get; set; }

        public string region { get; set; }

        public int telefono { get; set; }

        public List<PERSONAL> personal { get; set; }

        public SUCURSAL(int id, string ciudad, string region, int telefono)
        {
            this.id = id;
            this.ciudad = ciudad;
            this.region = region;
            this.telefono = telefono;
        }

        public SUCURSAL()
        {
            personal = new List<PERSONAL>();
        }

        void agregarPersonal(PERSONAL personal)
        {
            this.personal.Add(personal);
        }
    }
}
